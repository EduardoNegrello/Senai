DB_CONFIG = {
    'user': 'root',
    'password': 'DUDU230507',  
    'host': 'localhost',
    'database': 'ecommerce',
}
