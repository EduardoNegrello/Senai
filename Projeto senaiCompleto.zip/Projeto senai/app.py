from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash 
from config import DB_CONFIG
from flask import session
from flask import render_template
from models import usuario
from flask_bcrypt import Bcrypt

app = Flask(__name__)
bcrypt = Bcrypt(app)
app = Flask(__name__)
CORS(app)
app.secret_key = 'DUDU1010'
app = Flask(__name__, static_folder='static', template_folder='templates')
app.config.from_object(DB_CONFIG)
app.secret_key = 'DUDU1010'  

# Configuração do banco de dados
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Modelo do usuário
class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

with app.app_context():
    db.create_all()

# Rota para cadastro
@app.route('/register', methods=['POST'])
def register():
    data = request.json
    print("Recebi dados:", data)

    # Criptografar a senha
    hashed_password = bcrypt.generate_password_hash(data['password']).decode('utf-8')
    novo_usuario = Usuario(username=data['username'], email=data['email'], password=hashed_password)

    novo_usuario = Usuario(
        username=data['username'],
        email=data['email'],
        password=hashed_password
    )
    db.session.add(novo_usuario)
    db.session.commit()
    return jsonify({'mensagem': 'Usuário salvo!'}), 201


@app.route('/login', methods=['GET'])
def login_page():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    user = Usuario.query.filter_by(email=data['email']).first()

    if not user or not bcrypt.check_password_hash(user.password, data['password']):
        return jsonify({'erro': 'Credenciais inválidas.'}), 401

    # Salvar dados na sessão
    session['user_id'] = user.id
    session['user_email'] = user.email
    

    return jsonify({'mensagem': 'Login realizado com sucesso!'}), 200


# Rota para exibir o formulário
@app.route('/')
def formulario():
    return render_template('Html2.html')

# Rota para página de sucesso
@app.route('/HtmlZika.html')
def pagina_sucesso():
    nome_usuario = session.get('user_email')
    return render_template('HtmlZika.html', nome_usuario=nome_usuario)


if __name__ == '__main__':
    app.run(debug=True)
