DB_CONFIG = {
    'user': 'root',
    'password': 'DUDU230507',  # coloque a senha que você usa para o root
    'host': 'localhost',
    'database': 'ecommerce',
}
